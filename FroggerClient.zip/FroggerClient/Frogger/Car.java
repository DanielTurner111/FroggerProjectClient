import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

public class Car extends spriteCharacteristics implements Runnable {

	private Boolean moving;
	private Thread t;
	private JLabel carLabel;
	private JButton startButton;
	private gameCharacter gameCharacter;
	private JLabel frogLabel;
	private int speed;
	private Boolean moveLeft;
	
	
	public Car() {
		super();
		this.moving = false;
	}



	public Car (int x, int y, int width, int height, String image, Boolean moving, int speed, Boolean moveLeft) {
		
		super(x,y, width, height, image);
		this.moving = moving;
		this.speed = speed;
		this.moveLeft = moveLeft;
		
	}
	
	public Boolean getMoving() {return moving; }
	public void setMoving(Boolean moving) {this.moving = moving; }
	
	public void setGameCharacter( gameCharacter gameCharacter) {this.gameCharacter = gameCharacter;}
	public void setGameCharacterLabel(JLabel frogLabel) {this.frogLabel = frogLabel;}
	public void setCarLabels(JLabel carLabel) {this.carLabel = carLabel;}
	public JLabel getCarLabel() {return this.carLabel;}
	public void setStartButton(JButton startButton) {this.startButton = startButton;}
	
	public void run() {
		this.moving = true;
		startButton.setText("Stop");
		
		while(this.moving) {
			int x = this.x;
			
			if (moveLeft) {
				x -= speed;
				if (x + this.width < 0) x = froggerProperties.SCREEN_WIDTH;
			} else {
				x += speed;
				if (x > froggerProperties.SCREEN_WIDTH) x = -this.width;
			}
			
			this.setX(x);
			carLabel.setLocation(this.x, this.y);
			
			if (this.r.intersects(this.gameCharacter.getRectangle())) {
				System.out.println("Boom dead");
				this.moving = false;
				startButton.setText("Start");
				
				
				gameCharacter.setX(240);
				gameCharacter.setY(870);
				gameCharacter.r.setLocation(gameCharacter.getX(), gameCharacter.getY());
			}
			
			try { Thread.sleep(200); } catch(Exception e) { e.printStackTrace(); }
		
		}
		
	}
	
	public void startThread() {
		if (!this.moving) {
			t = new Thread(this, "movement thread");
			t.start();
		}
	}
	
	public void stopThread() {this.moving = false;} 
	
}

	

