
public class froggerProperties {
	
	public static final int SCREEN_WIDTH = 600;
	public static final int SCREEN_HEIGHT = 966;
	//no longer required due to car and log movement distances being dictated by carSpeed in the main file
	//public static final int CHARACTER_STEP = 10;
	public static final int HORIZONTAL_STEP = 15;
	public static final int VERTICAL_STEP = 83;
	

}
