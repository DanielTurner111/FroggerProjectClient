
public class Background extends spriteCharacteristics {

	public Background() {
		super();
	}

	public Background(int x, int y, int width, int height, String image) {
		super(x, y, width, height, image);
		
		
	}
	
}
