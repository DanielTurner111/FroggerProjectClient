import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Frogger extends JFrame implements KeyListener, ActionListener {
	
	private boolean onLog = false;
	private Background Background;
	private gameCharacter gameCharacter;
	
	private Car[][] cars;
	private JLabel[][] carLabels;
	
	private String Player;
	private int Score;
	
	private Log[][] logs;
	private JLabel[][] logLabels;
	
	private Container content;
	private JLabel backgroundLabel, frogLabel;
	private ImageIcon backgroundImage, frogImage;
	
	private JButton startButton;
	
	
	public Frogger() {
		
		String User = JOptionPane.showInputDialog("Please Enter Your Name For Score Tracking");
		JOptionPane.showMessageDialog(null, User);
		Player = User;
		
		content = getContentPane();
		
		Background = new Background(0,0, 600, 966, "Background.png");
		gameCharacter = new gameCharacter(100,250,100,100,"Frog.png");
		
		setSize(froggerProperties.SCREEN_WIDTH, froggerProperties.SCREEN_HEIGHT +30);
		content.setBackground(Color.gray);
		setLayout(null);
		
		gameCharacter.setX(240);
		gameCharacter.setY(870);
		gameCharacter.setWidth(66);
		gameCharacter.setHeight(66);
		gameCharacter.setImage("Frog.png");
		
		startButton = new JButton("Start");
		startButton.addActionListener(this);
		startButton.setSize(50,50);
		startButton.setLocation(froggerProperties.SCREEN_WIDTH -60 , froggerProperties.SCREEN_HEIGHT -90 );
		startButton.setFocusable(false);
		
		//Car.setgameCharacter(gameCharacter);
		//Car.setFrogLabel(frogLabel);
		
		//Log.setgameCharacter(gameCharacter);
		//sLog.setFrogLabel(frogLabel);
		
		backgroundLabel = new JLabel();
		backgroundImage = new ImageIcon(getClass().getResource("gameSprites/" + Background.getImage()));
		backgroundLabel.setIcon(backgroundImage);
		backgroundLabel.setSize(Background.getWidth(), Background.getHeight());
		backgroundLabel.setLocation(Background.getX(), Background.getY());
		
		frogLabel = new JLabel();
		frogImage = new ImageIcon(getClass().getResource("gameSprites/" + gameCharacter.getImage()));
		frogLabel.setIcon(frogImage);
		frogLabel.setSize(gameCharacter.getWidth(), gameCharacter.getHeight());
		frogLabel.setLocation(gameCharacter.getX(), gameCharacter.getY());
		
		int numCars = 3;
		int[] CarY = {790, 708, 620, 540};
		int[] carSpeed = {8, 10, 12, 11};
		
		cars = new Car[CarY.length][numCars];
		carLabels = new JLabel[CarY.length][numCars];
		
		
		for (int row = 0; row < CarY.length; row++) {
			for (int col = 0; col < numCars; col++) {
				
				int x = col * 250;
				Boolean moveLeft = (row %2 == 0 );
				String image = moveLeft ? "Car1.png" : "Car2.png";
				
				cars[row][col] = new Car (x, CarY[row], 125, 76, image, false, carSpeed[row], moveLeft);
				cars[row][col].setMoving(false);
				cars[row][col].setStartButton(startButton);
				cars[row][col].setGameCharacter(gameCharacter);
				cars[row][col].setGameCharacterLabel(frogLabel);
				
				carLabels[row][col] = new JLabel(new ImageIcon(
						getClass().getResource("gameSprites/" + cars[row][col].getImage())));
				carLabels[row][col].setSize(cars[row][col].getWidth(), cars[row][col].getHeight());
				carLabels[row][col].setLocation(cars[row][col].getX(), cars[row][col].getY());
				
				cars[row][col].setCarLabels(carLabels[row][col]);
				content.add(carLabels[row][col]);
			}	
		}
		
		content.add(startButton);
		content.add(frogLabel);
		
		int numLogs = 3;
		int[] LogY = {370, 290, 210, 130};
		int[] LogSpeed = {9, 5, 10, 13 };
		
		logs = new Log[LogY.length][numLogs];
		logLabels = new JLabel[LogY.length][numLogs];
		
		
		for (int row = 0; row < LogY.length; row++) {
			for (int col = 0; col < numCars; col++) {
				
				int x = col * 250;
				Boolean moveLeft = (row %2 == 0 );
				String image = moveLeft ? "Log.png" : "Log.png";
				
				logs[row][col] = new Log (x, LogY[row], 107, 43, image, false, LogSpeed[row], moveLeft);
				logs[row][col].setMoving(false);
				logs[row][col].setStartButton(startButton);
				logs[row][col].setGameCharacter(gameCharacter);
				logs[row][col].setGameCharacterLabel(frogLabel);
				
				logLabels[row][col] = new JLabel(new ImageIcon(
						getClass().getResource("gameSprites/" + logs[row][col].getImage())));
				logLabels[row][col].setSize(logs[row][col].getWidth(), logs[row][col].getHeight());
				logLabels[row][col].setLocation(logs[row][col].getX(), logs[row][col].getY());
				
				logs[row][col].setLogLabels(logLabels[row][col]);
				content.add(logLabels[row][col]);
			}	
		}
		
		//content.add(startButton);
		//content.add(frogLabel);
		content.add(backgroundLabel);
		
		content.addKeyListener(this);
		content.setFocusable(true);
		
		//in the 2012 animated Lorax a Thneed is a thing that can be used for everything. 
		// this thread runs most of the important functions relating to if the frog is alive.  It's also a really similar word to thread
		Thread Thneed = new Thread(() -> {
			while(true) {
				
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				SurfMove();
				frogLabel.setLocation(gameCharacter.getX(), gameCharacter.getY());
				Surfing();
				CarCrash();
				winner();
				
			}
			
		});
		
		Thneed.start();

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
			
	}
	
	public static void main(String[] args) {
		Frogger myGame = new Frogger();
		myGame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == startButton) {
			for (int row = 0; row < cars.length; row++) {
				for (int col = 0; col < cars[row].length; col++) {
					if (!cars[row][col].getMoving()) {
					cars[row][col].startThread();
					}
				}	
			}
			
			for (int row = 0; row < logs.length; row++) {
				for (int col = 0; col < logs[row].length; col++) {
					if (!logs[row][col].getMoving()) {
					logs[row][col].startThread(); 
					}
				}
			}
					
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	private void Surfing() {
		onLog =  false;
		for (int row = 0; row<logs.length; row++) {
			for (int col = 0; col < logs[row].length; col++) {
				if (gameCharacter.r.intersects(logs[row][col].getLogLabel().getBounds())) {
					onLog = true;
				}
			}
		}
		
		if (gameCharacter.getY() >= 100 && gameCharacter.getY() <= 420 && !onLog) {
			drowned();
		}
		
	}
	
	private void drowned() {
		gameCharacter.setX(240);
		gameCharacter.setY(870);
		gameCharacter.r.setLocation(gameCharacter.getX(), gameCharacter.getY());
		System.out.println("You're a frog the size of a car of course you can't swim");
		setScore(getScore() - 50);
		System.out.println("Score " + Score);
		System.out.println("Name " + Player);
	}
	
	private void SurfMove() {
		for (int row = 0; row<logs.length; row++) {
			for (int col = 0; col < logs[row].length; col++) {
				if (gameCharacter.r.intersects(logs[row][col].getLogLabel().getBounds())) {
					int frogX = gameCharacter.getX();
					Log riding = logs[row][col];
					frogX += riding.getMoveLeft() ? -riding.getSpeed() : riding.getSpeed();
					gameCharacter.setX(frogX);
					gameCharacter.r.setLocation(gameCharacter.getX(), gameCharacter.getY());
				}
			}
		}
	}
	
	private void CarCrash() {
		for (int row = 0; row<cars.length; row++) {
			for (int col = 0; col < cars[row].length; col++) {
				if (gameCharacter.r.intersects(cars[row][col].getCarLabel().getBounds())) {
					flattened();
				}
			}
		}	
	}
	
	private void flattened() {
		gameCharacter.setX(240);
		gameCharacter.setY(870);
		gameCharacter.r.setLocation(gameCharacter.getX(), gameCharacter.getY());
		System.out.println("You're a frog the size of a car of course you can't swim");
		setScore(getScore() - 50);
		System.out.println("Score " + Score);
		System.out.println("Name " + Player);
	}
		
	
	
	private void winner() {
		int winning = gameCharacter.getY();
		if (winning <= 100) {
			
			gameCharacter.setX(240);
			gameCharacter.setY(870);
			
			setScore(getScore() + 50);
			System.out.println("Score " + Score);
			System.out.println("Name " + Player);
			
		}
		
		
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		if (!startButton.getText().equals("Stop")) return;
		
		int x = gameCharacter.getX();
		int y = gameCharacter.getY();
		
		if ( e.getKeyCode() == KeyEvent.VK_UP ) {
			
			y -= froggerProperties.VERTICAL_STEP;
				 
			if (y < 0) {
				gameCharacter.setY(y);
			}
						
			} else if ( e.getKeyCode() == KeyEvent.VK_DOWN ) { 
				
				y += froggerProperties.VERTICAL_STEP;
				
				//I tried to make it so that if it goes any lower than where it starts it gets put back at the starting Y, but that didn't work
				//so this is what I need to go with
				if (y+gameCharacter.getHeight() > froggerProperties.SCREEN_HEIGHT) {
					y = froggerProperties.SCREEN_HEIGHT - gameCharacter.getWidth();
				}
				
			} else if ( e.getKeyCode() == KeyEvent.VK_LEFT ) { 
				
				x -= froggerProperties.HORIZONTAL_STEP;
				if (x < 0) {
					x = 0;
					gameCharacter.setX(x);
				}
				
			} else if ( e.getKeyCode() == KeyEvent.VK_RIGHT ) { 
				
				x += froggerProperties.HORIZONTAL_STEP;
				if (x+gameCharacter.getWidth() > froggerProperties.SCREEN_WIDTH) {
					x = froggerProperties.SCREEN_WIDTH - gameCharacter.getWidth();
				}
				
				
				
			} else {
				System.out.println("unrecognized key press");
			}
			
			gameCharacter.setX(x);
			gameCharacter.setY(y);
			
			
			//update location on screen
			frogLabel.setLocation( gameCharacter.getX(), gameCharacter.getY() );
			
			

			
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	public int getScore() {
		return Score;
	}

	public void setScore(int score) {
		Score = score;
	}

	public String getPlayer() {
		return Player;
	}

	public void setPlayer(String player) {
		Player = player;
	}

	

	
	
}


